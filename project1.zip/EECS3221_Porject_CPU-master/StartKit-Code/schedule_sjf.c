#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "task.h"
#include "schedulers.h"
#include "list.h"
#include "cpu.h"

struct node *linkedList = NULL;
struct node *scheduleList = NULL;
int countTask = 0;

// add a task to the list
void add(char *name, int priority, int burst)
{
    Task *nTask;
    nTask = malloc(sizeof(Task));
    nTask->name = malloc(sizeof(char));
    nTask->name = name;
    nTask->priority = priority;
    nTask->burst = burst;

    insert(&linkedList, nTask);
    countTask++;
}

void schedule()
{
    struct node *temp;
    temp = linkedList;
    int totalBurst = 0;
    int sum, watt, sum2 = 0;
    double avt, wat;

    while (temp != NULL)
    {
        insert(&scheduleList, temp->task);
        temp = temp->next;
    }
    sortList(scheduleList);
    while (scheduleList != NULL)
    {
        run(scheduleList->task, scheduleList->task->burst);
        totalBurst = totalBurst + scheduleList->task->burst;
        watt = totalBurst - scheduleList->task->burst;
        sum = sum + totalBurst;
        sum2 = sum2 + watt;
        scheduleList = scheduleList->next;
    }
    avt = (double)sum / countTask;
    wat = (double)sum2 / countTask;
    printf("\nAverage waiting time = %.2f\n", wat);
    printf("Average turnaround time = %.2f\n", avt);
    printf("Average response time = %.2f\n", wat);
}